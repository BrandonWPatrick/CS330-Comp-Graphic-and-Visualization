///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// manage the viewing of 3D objects within the viewport - camera, projection
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;

	// false = perspective, true = orthographic
	bool bOrthographicProjection = false;

	// used to prevent rapid toggling when holding keys down
	bool gToggleOWasDown = false;
	bool gTogglePWasDown = false;

	// movement speed clamp (manual clamp; avoids std::clamp issues)
	const float MIN_MOVE_SPEED = 2.0f;
	const float MAX_MOVE_SPEED = 60.0f;


	// Scroll callback (FREE FUNCTION so we don't need header changes)
	void Mouse_Scroll_Callback(GLFWwindow* window, double xoffset, double yoffset)
	{
		(void)window;
		(void)xoffset;

		if (g_pCamera == nullptr) return;

		float newSpeed = g_pCamera->MovementSpeed + (float)yoffset * 2.0f;

		if (newSpeed < MIN_MOVE_SPEED) newSpeed = MIN_MOVE_SPEED;
		if (newSpeed > MAX_MOVE_SPEED) newSpeed = MAX_MOVE_SPEED;

		g_pCamera->MovementSpeed = newSpeed;
	}
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(ShaderManager* pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;

	g_pCamera = new Camera();

	// default camera view parameters
	g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
	g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 80.0f;
	g_pCamera->MovementSpeed = 20.0f;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;

	if (g_pCamera != NULL)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, windowTitle, NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// tell GLFW to capture all mouse events
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// callbacks for mouse input
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	// IMPORTANT: register scroll callback so the mouse wheel works
	glfwSetScrollCallback(window, Mouse_Scroll_Callback);

	// enable blending for supporting transparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;
	return window;
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	(void)window;

	// In orthographic mode, do NOT rotate/orbit with the mouse.
	// This prevents the "dome rotation" behavior you described.
	if (bOrthographicProjection)
	{
		gFirstMouse = true;
		return;
	}

	// record first mouse event so offsets are correct
	if (gFirstMouse)
	{
		gLastX = (float)xMousePos;
		gLastY = (float)yMousePos;
		gFirstMouse = false;
	}

	// calculate offsets
	float xOffset = (float)xMousePos - gLastX;
	float yOffset = gLastY - (float)yMousePos; // reversed since y-coordinates go bottom->top

	// store last positions
	gLastX = (float)xMousePos;
	gLastY = (float)yMousePos;

	// move camera view direction
	if (g_pCamera != NULL)
	{
		g_pCamera->ProcessMouseMovement(xOffset, yOffset);
	}
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method is called to process any keyboard events
 *  that may be waiting in the event queue.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// close the window if the escape key has been pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	// if the camera object is null, then exit this method
	if (g_pCamera == NULL)
	{
		return;
	}

	// -------------------------
	// Camera movement (WASD + QE)
	// -------------------------
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);

	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);


	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);

	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);

	// Up/down (QE)
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(UP, gDeltaTime);

	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);

	// -------------------------
	// Projection toggle (O = orthographic, P = perspective)
	// Tap behavior so holding doesn't spam toggle.
	// -------------------------
	bool oDown = (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS);
	if (oDown && !gToggleOWasDown)
	{
		bOrthographicProjection = true;

		// Snap camera to a LEVEL view at the object so the floor is out of frame in ortho.
		// (Same Y for position and target => no downward pitch.)
		glm::vec3 orthoPos = glm::vec3(0.0f, 8.0f, 20.0f);
		glm::vec3 orthoTarget = glm::vec3(0.0f, 8.0f, 0.0f);

		g_pCamera->Position = orthoPos;
		g_pCamera->Front = glm::normalize(orthoTarget - orthoPos);
		g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);

		gFirstMouse = true;
	}
	gToggleOWasDown = oDown;

	bool pDown = (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS);
	if (pDown && !gTogglePWasDown)
	{
		bOrthographicProjection = false;

		// Return to a typical perspective view
		g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
		g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
		g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);

		gFirstMouse = true;
	}
	gTogglePWasDown = pDown;
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  This method is used for preparing the 3D scene view
 *  matrices for rendering.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// per-frame timing
	float currentFrame = (float)glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// process any keyboard events that may be waiting in the event queue
	ProcessKeyboardEvents();

	// get the current view matrix from the camera
	view = g_pCamera->GetViewMatrix();

	// define the current projection matrix
	if (!bOrthographicProjection)
	{
		// Perspective projection (3D)
		projection = glm::perspective(
			glm::radians(g_pCamera->Zoom),
			(GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT,
			0.1f,
			100.0f);
	}
	else
	{
		// Orthographic projection (2D-like)
		// Smaller ortho size to clip out the floor (y=0) when camera Y=8.
		float orthoSize = 12.0f;
		float aspect = (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT;

		projection = glm::ortho(
			-orthoSize * aspect, orthoSize * aspect,
			-orthoSize, orthoSize,
			0.1f, 100.0f);
	}

	// if the shader manager object is valid
	if (m_pShaderManager != NULL)
	{
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ViewName, view);
		// set the projection matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		// set the view position of the camera into the shader for proper rendering
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}
