///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream>

namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;
}

SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	stbi_set_flip_vertically_on_load(true);
	unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

	if (!image)
	{
		std::cout << "Could not load image: " << filename << std::endl;
		return false;
	}

	std::cout << "Successfully loaded image: " << filename
		<< " width: " << width
		<< " height: " << height
		<< " channels: " << colorChannels << std::endl;

	glGenTextures(1, &textureID);
	glBindTexture(GL_TEXTURE_2D, textureID);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	if (colorChannels == 3)
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	else if (colorChannels == 4)
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
	else
	{
		std::cout << "Unsupported channel count: " << colorChannels << " for " << filename << std::endl;
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0);
		return false;
	}

	glGenerateMipmap(GL_TEXTURE_2D);

	stbi_image_free(image);
	glBindTexture(GL_TEXTURE_2D, 0);

	m_textureIDs[m_loadedTextures].ID = textureID;
	m_textureIDs[m_loadedTextures].tag = tag;
	m_loadedTextures++;

	return true;
}

void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
	m_loadedTextures = 0;
}

int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return textureID;
}

int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return textureSlot;
}

bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return false;
	}

	int index = 0;
	bool bFound = false;

	while ((index < (int)m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return bFound;
}

void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	scale = glm::scale(scaleXYZ);

	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));

	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

void SceneManager::SetShaderColor(float r, float g, float b, float a)
{
	glm::vec4 currentColor(r, g, b, a);

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

void SceneManager::SetShaderTexture(std::string textureTag)
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	int textureSlot = FindTextureSlot(textureTag);
	if (textureSlot < 0)
	{
		std::cout << "Texture tag not found: " << textureTag << std::endl;
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		return;
	}

	m_pShaderManager->setIntValue(g_UseTextureName, true);
	m_pShaderManager->setSampler2DValue(g_TextureValueName, textureSlot);

	// Texture color multiplier
	m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(1, 1, 1, 1));
}

void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

void SceneManager::SetShaderMaterial(std::string materialTag)
{
	if (m_objectMaterials.size() == 0 || NULL == m_pShaderManager)
	{
		return;
	}

	OBJECT_MATERIAL material;
	bool bFound = FindMaterial(materialTag, material);
	if (bFound)
	{
		m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
		m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
		m_pShaderManager->setFloatValue("material.shininess", material.shininess);
	}
}

glm::vec3 SceneManager::RotateOffsetY(const glm::vec3& offset, float degrees)
{
	glm::mat4 R = glm::rotate(glm::mat4(1.0f), glm::radians(degrees), glm::vec3(0.0f, 1.0f, 0.0f));
	return glm::vec3(R * glm::vec4(offset, 1.0f));
}

void SceneManager::PrepareScene()
{
	// Mesh assets
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadPrismMesh();

	// Texture assets
	CreateGLTexture("textures/cracked_concrete_wall_diff_4k.jpg", "wall");
	CreateGLTexture("textures/rock_boulder_dry_diff_4k.jpg", "concrete");
	CreateGLTexture("textures/cobblestone_floor_01_diff_4k.jpg", "cobblestone");
	CreateGLTexture("textures/wood_planks_dirt_diff_4k.jpg", "wood");
	BindGLTextures();

	// Material response
	OBJECT_MATERIAL stoneMat;
	stoneMat.tag = "stone";
	stoneMat.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	stoneMat.specularColor = glm::vec3(0.25f, 0.25f, 0.25f);
	stoneMat.shininess = 16.0f;
	m_objectMaterials.push_back(stoneMat);

	// Lighting enabled
	if (NULL == m_pShaderManager)
		return;

	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Non-point light sources disabled
	m_pShaderManager->setBoolValue("directionalLight.bActive", false);
	m_pShaderManager->setBoolValue("spotLight.bActive", false);

	// Point light array state
	for (int i = 0; i < 5; i++)
	{
		std::string base = "pointLights[" + std::to_string(i) + "]";
		m_pShaderManager->setBoolValue(base + ".bActive", false);
	}

	// Warm key light
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);
	m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(10.0f, 14.0f, 16.0f));
	m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.05f, 0.035f, 0.020f));
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(0.85f, 0.50f, 0.20f));
	m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(0.35f, 0.25f, 0.18f));

	// Blue fill light
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);
	m_pShaderManager->setVec3Value("pointLights[1].position", glm::vec3(-14.0f, 10.0f, -16.0f));
	m_pShaderManager->setVec3Value("pointLights[1].ambient", glm::vec3(0.015f, 0.020f, 0.040f));
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", glm::vec3(0.10f, 0.25f, 0.85f));
	m_pShaderManager->setVec3Value("pointLights[1].specular", glm::vec3(0.08f, 0.10f, 0.22f));
}

void SceneManager::DrawArch(glm::vec3 basePosition, float baseRotationY, float uniformScale)
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;
	glm::vec3 localOffset;

	// Pillar bases
	SetShaderTexture("concrete");
	SetTextureUVScale(2.0f, 2.0f);

	const float plateWidth = 2.5f;
	const float plateHeight = 11.0f;
	const float plateDepth = 2.5f;

	scaleXYZ = glm::vec3(plateWidth, plateHeight, plateDepth) * uniformScale;
	localOffset = glm::vec3(-6.0f, plateHeight * 0.5f, 0.0f) * uniformScale;
	positionXYZ = basePosition + RotateOffsetY(localOffset, baseRotationY);
	SetTransformations(scaleXYZ, 0.0f, baseRotationY, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(plateWidth, plateHeight, plateDepth) * uniformScale;
	localOffset = glm::vec3(6.0f, plateHeight * 0.5f, 0.0f) * uniformScale;
	positionXYZ = basePosition + RotateOffsetY(localOffset, baseRotationY);
	SetTransformations(scaleXYZ, 0.0f, baseRotationY, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	// Arch wedges
	SetShaderTexture("wall");
	SetTextureUVScale(2.0f, 2.0f);

	glm::vec3 prismScale = glm::vec3(10.0f, 2.0f, 4.0f) * uniformScale;
	const float prismX = -90.0f;
	const float prismTiltZ = 50.0f;

	localOffset = glm::vec3(-5.6f, 15.5f, 0.0f) * uniformScale;
	positionXYZ = basePosition + RotateOffsetY(localOffset, baseRotationY);

	glm::mat4 modelLeft =
		glm::translate(positionXYZ) *
		glm::rotate(glm::mat4(1.0f), glm::radians(baseRotationY), glm::vec3(0, 1, 0)) *
		glm::rotate(glm::mat4(1.0f), glm::radians(prismTiltZ), glm::vec3(0, 0, 1)) *
		glm::rotate(glm::mat4(1.0f), glm::radians(prismX), glm::vec3(1, 0, 0)) *
		glm::scale(prismScale);

	m_pShaderManager->setMat4Value(g_ModelName, modelLeft);
	m_basicMeshes->DrawPrismMesh();

	localOffset = glm::vec3(5.6f, 15.5f, 0.0f) * uniformScale;
	positionXYZ = basePosition + RotateOffsetY(localOffset, baseRotationY);

	glm::mat4 modelRight =
		glm::translate(positionXYZ) *
		glm::rotate(glm::mat4(1.0f), glm::radians(baseRotationY), glm::vec3(0, 1, 0)) *
		glm::rotate(glm::mat4(1.0f), glm::radians(-prismTiltZ), glm::vec3(0, 0, 1)) *
		glm::rotate(glm::mat4(1.0f), glm::radians(prismX), glm::vec3(1, 0, 0)) *
		glm::scale(prismScale);

	m_pShaderManager->setMat4Value(g_ModelName, modelRight);
	m_basicMeshes->DrawPrismMesh();

	// Arch curve
	SetShaderTexture("wall");
	SetTextureUVScale(4.0f, 2.0f);

	glm::vec3 torusScale = glm::vec3(6.0f, 6.0f, 6.0f) * uniformScale;
	glm::vec3 torusLocalOffset = glm::vec3(0.0f, 11.0f, 0.0f) * uniformScale;
	positionXYZ = basePosition + RotateOffsetY(torusLocalOffset, baseRotationY);

	glm::mat4 modelTorus =
		glm::translate(positionXYZ) *
		glm::rotate(glm::mat4(1.0f), glm::radians(baseRotationY), glm::vec3(0, 1, 0)) *
		glm::rotate(glm::mat4(1.0f), glm::radians(180.0f), glm::vec3(0, 0, 1)) *
		glm::rotate(glm::mat4(1.0f), glm::radians(90.0f), glm::vec3(1, 0, 0)) *
		glm::scale(torusScale);

	m_pShaderManager->setMat4Value(g_ModelName, modelTorus);
	m_basicMeshes->DrawHalfTorusMesh();

	// Arch cap bar
	SetShaderTexture("wall");
	SetTextureUVScale(3.0f, 1.0f);

	glm::vec3 barScale = glm::vec3(15.0f, 3.0f, 5.5f) * uniformScale;
	glm::vec3 barLocalOffset = glm::vec3(0.0f, 18.0f, 0.0f) * uniformScale;
	glm::vec3 barPos = basePosition + RotateOffsetY(barLocalOffset, baseRotationY);

	glm::mat4 modelBar =
		glm::translate(barPos) *
		glm::rotate(glm::mat4(1.0f), glm::radians(baseRotationY), glm::vec3(0, 1, 0)) *
		glm::scale(barScale);

	m_pShaderManager->setMat4Value(g_ModelName, modelBar);
	m_basicMeshes->DrawBoxMesh();
}

void SceneManager::DrawWindowSegment(glm::vec3 basePosition, float baseRotationY, float uniformScale)
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;
	glm::vec3 localOffset;

	// Window frame segments
	SetShaderTexture("wall");
	SetTextureUVScale(2.0f, 2.0f);

	const float segWidth = 7.5f;
	const float segHeight = 7.0f;
	const float segDepth = 0.7f;

	const float winWidth = 1.4f;
	const float winHeight = 1.6f;

	const float frameX = (segWidth - winWidth) * 0.5f;
	const float frameY = (segHeight - winHeight) * 0.5f;

	scaleXYZ = glm::vec3(frameX, segHeight, segDepth) * uniformScale;
	localOffset = glm::vec3(-(winWidth * 0.5f + frameX * 0.5f), 0.0f, 0.0f) * uniformScale;
	positionXYZ = basePosition + RotateOffsetY(localOffset, baseRotationY);
	SetTransformations(scaleXYZ, 0.0f, baseRotationY, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(frameX, segHeight, segDepth) * uniformScale;
	localOffset = glm::vec3((winWidth * 0.5f + frameX * 0.5f), 0.0f, 0.0f) * uniformScale;
	positionXYZ = basePosition + RotateOffsetY(localOffset, baseRotationY);
	SetTransformations(scaleXYZ, 0.0f, baseRotationY, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(winWidth, frameY, segDepth) * uniformScale;
	localOffset = glm::vec3(0.0f, (winHeight * 0.5f + frameY * 0.5f), 0.0f) * uniformScale;
	positionXYZ = basePosition + RotateOffsetY(localOffset, baseRotationY);
	SetTransformations(scaleXYZ, 0.0f, baseRotationY, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(winWidth, frameY, segDepth) * uniformScale;
	localOffset = glm::vec3(0.0f, -(winHeight * 0.5f + frameY * 0.5f), 0.0f) * uniformScale;
	positionXYZ = basePosition + RotateOffsetY(localOffset, baseRotationY);
	SetTransformations(scaleXYZ, 0.0f, baseRotationY, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();
}

void SceneManager::RenderScene()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	// Camera specular reference
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec3Value("viewPosition", glm::vec3(0.0f, 8.0f, 20.0f));
	}

	SetShaderMaterial("stone");

	// Ground surface
	SetShaderTexture("cobblestone");
	SetTextureUVScale(6.0f, 6.0f);
	scaleXYZ = glm::vec3(30.0f, 1.0f, 30.0f);
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawPlaneMesh();

	// Colosseum base
	SetShaderTexture("concrete");
	SetTextureUVScale(6.0f, 3.0f);

	const float baseRadius = 14.0f;
	const float baseHeight = 0.6f;
	const float baseY = baseHeight * 0.5f + 0.02f;

	scaleXYZ = glm::vec3(baseRadius, baseHeight, baseRadius);
	positionXYZ = glm::vec3(0.0f, baseY, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	// Inner ring 1
	SetShaderTexture("wood");
	SetTextureUVScale(8.0f, 2.0f);

	const float innerWallRadius = 12.7f;
	const float ringThickness = 1.0f;
	const float ringOuterRadius = innerWallRadius - 0.3f;
	const float ringMajor = ringOuterRadius - ringThickness;

	glm::vec3 ringScale = glm::vec3(ringMajor, ringThickness, ringMajor);
	glm::vec3 ringPos = glm::vec3(0.0f, 3.8f, 0.0f);

	SetTransformations(ringScale, 0.0f, 0.0f, 0.0f, ringPos);
	m_basicMeshes->DrawTorusMesh();

	// Inner ring 2
	SetShaderTexture("wood");
	SetTextureUVScale(8.0f, 2.0f);

	const float innerRing2Inset = 0.5f;
	const float ring2Thickness = 0.5f;
	const float ring2OuterRadius = ringOuterRadius - innerRing2Inset;
	const float ring2Major = ring2OuterRadius - ring2Thickness;

	glm::vec3 ring2Scale = glm::vec3(ring2Major, 1.5f, ring2Major);
	glm::vec3 ring2Pos = glm::vec3(0.0f, 2.3f, 0.0f);

	GLboolean cullWasEnabled2 = glIsEnabled(GL_CULL_FACE);
	if (cullWasEnabled2) glDisable(GL_CULL_FACE);

	SetTransformations(ring2Scale, 0.0f, 0.0f, 0.0f, ring2Pos);
	m_basicMeshes->DrawTorusMesh();

	if (cullWasEnabled2) glEnable(GL_CULL_FACE);

	// Arch rings
	int levelCount = 3;

	for (int i = 0; i < levelCount; i++)
	{
		float levelHeight = i * 1.4f;

		glm::vec3 ringCenter = glm::vec3(0.0f, 0.8f + levelHeight, 0.0f);
		float ringRadius = 13.8f;
		int archCount = 80;
		float archScale = 0.085f;

		for (int j = 0; j < archCount; j++)
		{
			float t = (float)j / (float)archCount;
			float angle = t * glm::two_pi<float>();

			float x = ringCenter.x + cos(angle) * ringRadius;
			float z = ringCenter.z + sin(angle) * ringRadius;

			float rotY = glm::degrees(angle) + 90.0f;

			DrawArch(glm::vec3(x, ringCenter.y, z), -rotY, archScale);
		}
	}

	// Top wall windows
	int windowCount = 40;
	float windowRingRadius = 13.8f;
	float windowY = 2.0f + (levelCount * 1.4f);
	float windowScale = 0.3f;

	for (int k = 0; k < windowCount; k++)
	{
		float t = (float)k / (float)windowCount;
		float angle = t * glm::two_pi<float>();

		float x = cos(angle) * windowRingRadius;
		float z = sin(angle) * windowRingRadius;

		float rotY = glm::degrees(angle) + 90.0f;

		DrawWindowSegment(glm::vec3(x, windowY, z), -rotY, windowScale);
	}
}